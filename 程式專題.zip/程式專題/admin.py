import json
import database

STATUS_FLOW = {
    "1": "備餐中",
    "2": "可取餐",
    "3": "已完成",
    "4": "已取消"
}

def admin_panel():
    """店家管理後台選單"""
    while True:
        print("\n" + "=" * 45)
        print("👨‍🍳 【店家後台管理系統】")
        print("1. 查看所有訂單列表")
        print("2. 更新訂單備餐狀態")
        print("3. 補充餐點庫存")
        print("0. 返回主選單")
        print("=" * 45)
        choice = input("請選擇操作：").strip()

        if choice == "1":
            orders = database.get_all_orders()
            if not orders:
                print("📭 目前尚無任何訂單。")
                continue
            print("\n--- 所有訂單列表 ---")
            for oid, number, items_json, total, status in orders:
                items = json.loads(items_json)
                summary = ", ".join([f"{i['name']}x{i['qty']}" for i in items])
                print(f"[ID:{oid}] 號碼:{number} | 狀態:【{status}】 | ${total} | 內容:{summary}")

        elif choice == "2":
            order_id = input("請輸入要更新的訂單 ID：").strip()
            if not order_id.isdigit():
                print("❌ 請輸入正確的數字 ID！")
                continue
            print("選擇新狀態： 1.備餐中  2.可取餐  3.已完成  4.已取消")
            s_choice = input("請輸入狀態編號：").strip()
            if s_choice in STATUS_FLOW:
                new_status = STATUS_FLOW[s_choice]
                if database.update_order_status(int(order_id), new_status):
                    print(f"✅ 訂單 ID {order_id} 狀態已更新為【{new_status}】！")
                else:
                    print("❌ 找不到該訂單 ID！")
            else:
                print("❌ 無效的狀態選項！")

        elif choice == "3":
            item_id = input("請輸入要補貨的餐點編號：").strip()
            add_qty = input("請輸入增加的庫存數量：").strip()
            if item_id.isdigit() and add_qty.isdigit():
                database.update_stock(int(item_id), int(add_qty))
                print("✅ 庫存更新成功！")
            else:
                print("❌ 請輸入有效的數字！")

        elif choice == "0":
            break
        else:
            print("❌ 無效的選項，請重新輸入。")