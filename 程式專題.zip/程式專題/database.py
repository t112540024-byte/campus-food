import sqlite3
import json

DB_NAME = "campus_food.db"

def get_connection():
    return sqlite3.connect(DB_NAME)

def init_db():
    """初始化資料表與預設菜單"""
    conn = get_connection()
    cursor = conn.cursor()

    # 建立菜單表
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS menu (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price INTEGER NOT NULL,
            stock INTEGER NOT NULL
        )
    """)

    # 建立訂單表
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pickup_number TEXT NOT NULL,
            items_json TEXT NOT NULL,
            total_price INTEGER NOT NULL,
            status TEXT NOT NULL
        )
    """)

    # 若菜單為空，自動寫入預設學餐品項
    cursor.execute("SELECT COUNT(*) FROM menu")
    if cursor.fetchone()[0] == 0:
        default_items = [
            ("招牌雞腿飯", 95, 20),
            ("香酥排骨飯", 85, 15),
            ("牛肉起司堡", 75, 25),
            ("日式豬排丼", 90, 10),
            ("古早味紅茶", 25, 50)
        ]
        cursor.executemany("INSERT INTO menu (name, price, stock) VALUES (?, ?, ?)", default_items)

    conn.commit()
    conn.close()

def get_all_menu():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, stock FROM menu")
    rows = cursor.fetchall()
    conn.close()
    return rows

def get_menu_item(item_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, price, stock FROM menu WHERE id = ?", (item_id,))
    row = cursor.fetchone()
    conn.close()
    return row

def update_stock(item_id, delta):
    """更新庫存（delta 為負數表示扣除庫存）"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE menu SET stock = stock + ? WHERE id = ?", (delta, item_id))
    conn.commit()
    conn.close()

def save_order(pickup_number, items, total_price):
    conn = get_connection()
    cursor = conn.cursor()
    items_json = json.dumps(items, ensure_ascii=False)
    cursor.execute(
        "INSERT INTO orders (pickup_number, items_json, total_price, status) VALUES (?, ?, ?, ?)",
        (pickup_number, items_json, total_price, "已接單")
    )
    conn.commit()
    conn.close()

def get_all_orders():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, pickup_number, items_json, total_price, status FROM orders ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()
    return rows

def get_order_by_pickup(pickup_number):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, pickup_number, items_json, total_price, status FROM orders WHERE pickup_number = ?",
        (pickup_number,)
    )
    row = cursor.fetchone()
    conn.close()
    return row

def update_order_status(order_id, new_status):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE orders SET status = ? WHERE id = ?", (new_status, order_id))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0