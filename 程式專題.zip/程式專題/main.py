import database
import menu
from cart import Cart
import order
import admin

def main():
    # 啟動時初始化 SQLite 資料庫
    database.init_db()
    cart = Cart()

    while True:
        print("\n" + "=" * 45)
        print("🍱 歡迎使用【智慧學餐快速點餐系統】")
        print("=" * 45)
        print("1. 瀏覽學餐菜單")
        print("2. 點餐（加入購物車 & 客製化）")
        print("3. 查看 / 刪除購物車餐點")
        print("4. 送出訂單（結帳並取得取餐號碼）")
        print("5. 查詢取餐進度（輸入取餐號碼）")
        print("6. 店家後台管理（接單 / 更新備餐狀態）")
        print("0. 離開系統")
        print("=" * 45)

        choice = input("請選擇功能 (0-6)：").strip()

        if choice == "1":
            menu.show_menu()

        elif choice == "2":
            menu.show_menu()
            item_id_str = input("請輸入要點的餐點編號：").strip()
            qty_str = input("請輸入數量：").strip()
            if not (item_id_str.isdigit() and qty_str.isdigit()):
                print("❌ 編號與數量請輸入數字！")
                continue

            print("客製化加購選項（可複選，用逗號分隔，不加購請直接按 Enter）：")
            print("  1. 起司 (+10元)   2. 加大 (+15元)")
            opt_input = input("請輸入加購編號：").strip()
            opt_keys = [k.strip() for k in opt_input.split(",")] if opt_input else []

            cart.add_item(int(item_id_str), int(qty_str), opt_keys)

        elif choice == "3":
            cart.show_cart()
            if cart.items:
                del_choice = input("如需刪除項目請輸入購物車編號（不刪除請直接按 Enter）：").strip()
                if del_choice.isdigit():
                    cart.remove_item(int(del_choice) - 1)

        elif choice == "4":
            cart.show_cart()
            if cart.items:
                confirm = input("確定要送出訂單嗎？(y/n)：").strip().lower()
                if confirm == "y":
                    order.create_order(cart)

        elif choice == "5":
            pickup_num = input("請輸入您的取餐號碼（例如 A1205-384）：")
            order.check_order_status(pickup_num)

        elif choice == "6":
            admin.admin_panel()

        elif choice == "0":
            print("👋 感謝使用學餐點餐系統，祝您用餐愉快！")
            break

        else:
            print("❌ 無效的選項，請輸入 0 到 6 之間的數字。")

if __name__ == "__main__":
    main()