import streamlit as st
import json
import database
from cart import Cart
import order

# 初始化資料庫
database.init_db()

# 利用 session_state 保存使用者的購物車（網頁重新整理不會消失）
if "cart" not in st.session_state:
    st.session_state.cart = Cart()

st.set_page_config(page_title="智慧學餐快速點餐系統", page_icon="🍱")
st.title("🍱 智慧學餐快速點餐系統")

# 側邊欄切換「學生點餐」與「店家後台」
page = st.sidebar.radio("請選擇功能頁面", ["🛒 學生線上點餐", "🔍 查詢取餐進度", "👨‍🍳 店家後台管理"])

# --- 頁面 1：學生線上點餐 ---
if page == "🛒 學生線上點餐":
    st.header("今日學餐菜單")
    menu_items = database.get_all_menu()

    # 顯示菜單表格
    for item_id, name, price, stock in menu_items:
        col1, col2, col3, col4 = st.columns([3, 2, 2, 3])
        col1.write(f"**{name}**")
        col2.write(f"${price}")
        col3.write(f"剩餘 {stock} 份" if stock > 0 else "❌ 已售完")

        if stock > 0:
            with col4.popover("點餐 / 客製化"):
                qty = st.number_input("數量", min_value=1, max_value=stock, value=1, key=f"qty_{item_id}")
                add_cheese = st.checkbox("加起司 (+10元)", key=f"c_{item_id}")
                add_large = st.checkbox("加大 (+15元)", key=f"l_{item_id}")

                if st.button("加入購物車", key=f"btn_{item_id}"):
                    opts = []
                    if add_cheese: opts.append("1")
                    if add_large: opts.append("2")
                    st.session_state.cart.add_item(item_id, qty, opts)
                    st.success(f"已將 {name} x{qty} 加入購物車！")

    st.divider()
    st.subheader("🛍️ 我的購物車")
    cart = st.session_state.cart

    if not cart.items:
        st.info("購物車目前是空的，請從上方菜單點餐。")
    else:
        for idx, item in enumerate(cart.items):
            opt_str = f" ({', '.join(item['options'])})" if item["options"] else ""
            c1, c2 = st.columns([4, 1])
            c1.write(f"{idx+1}. {item['name']}{opt_str} x{item['qty']} — **${item['subtotal']}**")
            if c2.button("刪除", key=f"del_{idx}"):
                cart.remove_item(idx)
                st.rerun()

        st.markdown(f"### 💰 總計金額：`${cart.get_total()}`")
        if st.button("✅ 確認送出訂單", type="primary"):
            pickup_num = order.create_order(cart)
            if pickup_num:
                st.balloons()
                st.success(f"🎉 訂單建立成功！您的取餐號碼為：【 {pickup_num} 】")

# --- 頁面 2：查詢取餐進度 ---
elif page == "🔍 查詢取餐進度":
    st.header("查詢訂單與備餐進度")
    pickup_input = st.text_input("請輸入您的取餐號碼（例如 A1205-384）：").strip().upper()

    if st.button("查詢狀態") and pickup_input:
        result = database.get_order_by_pickup(pickup_input)
        if not result:
            st.error("找不到此取餐號碼，請確認是否輸入正確。")
        else:
            _, number, items_json, total_price, status = result
            st.info(f"🎫 取餐號碼：**{number}** ｜ 📢 目前狀態：**【 {status} 】**")
            items = json.loads(items_json)
            for i in items:
                st.write(f"- {i['name']} x{i['qty']} (${i['subtotal']})")
            st.write(f"**總金額：${total_price}**")

# --- 頁面 3：店家後台管理 ---
elif page == "👨‍🍳 店家後台管理":
    st.header("店家接單與備餐看板")
    orders = database.get_all_orders()

    if not orders:
        st.write("目前尚無任何訂單。")
    else:
        for oid, number, items_json, total, status in orders:
            with st.expander(f"訂單 #{oid} | 取餐號：{number} | 狀態：【{status}】 | ${total}", expanded=True):
                items = json.loads(items_json)
                for i in items:
                    opt_str = f" ({', '.join(i['options'])})" if i["options"] else ""
                    st.write(f"• {i['name']}{opt_str} x{i['qty']}")

                new_status = st.selectbox(
                    "更改訂單狀態",
                    ["已接單", "備餐中", "可取餐", "已完成", "已取消"],
                    index=["已接單", "備餐中", "可取餐", "已完成", "已取消"].index(status),
                    key=f"status_{oid}"
                )
                if st.button("更新狀態", key=f"upd_{oid}"):
                    database.update_order_status(oid, new_status)
                    st.success(f"訂單 {number} 已更新為【{new_status}】！")
                    st.rerun()