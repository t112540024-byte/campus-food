import database

# 客製化加價選項對照表
CUSTOM_OPTIONS = {
    "1": ("起司", 10),
    "2": ("加大", 15)
}

class Cart:
    def __init__(self):
        # 儲存格式: [{"item_id": int, "name": str, "base_price": int, "qty": int, "options": list, "subtotal": int}]
        self.items = []

    def add_item(self, item_id, qty, option_keys=None):
        """新增餐點至購物車並計算客製化加價"""
        menu_item = database.get_menu_item(item_id)
        if not menu_item:
            print("❌ 查無此餐點編號！")
            return False

        _, name, base_price, stock = menu_item
        if qty <= 0:
            print("❌ 數量必須大於 0！")
            return False

        # 檢查購物車內已選數量 + 新增數量是否超過庫存
        existing_qty = sum(i["qty"] for i in self.items if i["item_id"] == item_id)
        if existing_qty + qty > stock:
            print(f"❌ 庫存不足！目前僅剩 {stock - existing_qty} 份可點。")
            return False

        # 處理客製化加價
        selected_options = []
        extra_cost = 0
        if option_keys:
            for key in option_keys:
                if key in CUSTOM_OPTIONS:
                    opt_name, opt_price = CUSTOM_OPTIONS[key]
                    selected_options.append(f"{opt_name}(+${opt_price})")
                    extra_cost += opt_price

        unit_total = base_price + extra_cost
        subtotal = unit_total * qty

        self.items.append({
            "item_id": item_id,
            "name": name,
            "base_price": base_price,
            "qty": qty,
            "options": selected_options,
            "subtotal": subtotal
        })
        opt_text = f" [{', '.join(selected_options)}]" if selected_options else ""
        print(f"✅ 已加入購物車：{name}{opt_text} x{qty}（小計 ${subtotal}）")
        return True

    def remove_item(self, index):
        """依購物車項目編號刪除餐點"""
        if 0 <= index < len(self.items):
            removed = self.items.pop(index)
            print(f"🗑️ 已移除：{removed['name']} x{removed['qty']}")
        else:
            print("❌ 無效的購物車編號！")

    def get_total(self):
        """計算購物車總金額"""
        return sum(item["subtotal"] for item in self.items)

    def show_cart(self):
        """顯示目前購物車明細"""
        print("\n" + "-" * 45)
        print("🛒 目前購物車內容：")
        if not self.items:
            print("   （購物車目前是空的）")
        else:
            for idx, item in enumerate(self.items, start=1):
                opt_text = f" ({', '.join(item['options'])})" if item["options"] else ""
                print(f"   {idx}. {item['name']}{opt_text} x{item['qty']} - ${item['subtotal']}")
            print("-" * 45)
            print(f"💰 總計金額：${self.get_total()}")
        print("-" * 45)

    def clear(self):
        self.items = []