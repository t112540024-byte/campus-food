import json
import random
from datetime import datetime
import database

def generate_pickup_number():
    """產生取餐號碼（格式：時分 + 3位隨機碼，例如 A1205-384）"""
    time_part = datetime.now().strftime("%H%M")
    rand_part = random.randint(100, 999)
    return f"A{time_part}-{rand_part}"

def create_order(cart):
    """將購物車轉為正式訂單並寫入資料庫"""
    if not cart.items:
        print("❌ 購物車是空的，無法建立訂單！")
        return None

    # 再次確認庫存並扣除庫存
    for item in cart.items:
        db_item = database.get_menu_item(item["item_id"])
        if not db_item or db_item[3] < item["qty"]:
            print(f"❌ 建立訂單失敗：【{item['name']}】庫存不足！")
            return None

    for item in cart.items:
        database.update_stock(item["item_id"], -item["qty"])

    pickup_number = generate_pickup_number()
    total_price = cart.get_total()
    database.save_order(pickup_number, cart.items, total_price)
    cart.clear()

    print("\n" + "=" * 45)
    print("🎉 訂單建立成功！")
    print(f"🎫 您的取餐號碼：【 {pickup_number} 】")
    print(f"💵 應付金額：${total_price}")
    print("📌 目前狀態：已接單（請憑取餐號碼查詢進度）")
    print("=" * 45)
    return pickup_number

def check_order_status(pickup_number):
    """依取餐號碼查詢訂單狀態"""
    order = database.get_order_by_pickup(pickup_number.strip().upper())
    if not order:
        print("❌ 找不到此取餐號碼的訂單，請確認輸入是否正確。")
        return

    _, number, items_json, total_price, status = order
    items = json.loads(items_json)

    print("\n" + "-" * 45)
    print(f"🎫 取餐號碼：{number}")
    print(f"📢 目前狀態：【 {status} 】")
    print("📋 餐點明細：")
    for item in items:
        opt_text = f" ({', '.join(item['options'])})" if item["options"] else ""
        print(f"   - {item['name']}{opt_text} x{item['qty']} (${item['subtotal']})")
    print(f"💰 總金額：${total_price}")
    print("-" * 45)