import database

def show_menu():
    """顯示所有餐點、價格與剩餘庫存"""
    items = database.get_all_menu()
    print("\n" + "=" * 45)
    print(f"{'編號':<6}{'餐點名稱':<16}{'單價':<8}{'剩餘庫存'}")
    print("-" * 45)
    for item_id, name, price, stock in items:
        stock_str = f"{stock} 份" if stock > 0 else "已售完"
        print(f"{item_id:<8}{name:<15}${price:<9}{stock_str}")
    print("=" * 45)